#!/bin/bash

echo "I am starting ..."
