Just a simple CF application to test Grafana

Change the parameters in the manifest and push to CF with `cf push`.
